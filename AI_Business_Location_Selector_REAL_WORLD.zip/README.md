# Real-World AI Business Location Selector

This version does **not** use a synthetic business-location dataset.

It analyzes user-supplied candidate locations using live geographic information:
- OpenStreetMap / Overpass: nearby competitors, facilities, transport and mapped road signals
- Geocoding: converts candidate addresses to coordinates and may provide contextual population
- Open-Meteo: current weather context
- User-provided property rent: prevents invented rent values

The application produces a transparent 0-100 suitability ranking using business-specific priorities.

## Run
```bash
pip install -r requirements.txt
streamlit run app.py
```

## Important
Public map data is incomplete in some areas. Footfall is represented by a geographic activity proxy unless the user supplies measured footfall. The application should therefore be used for screening and decision support, followed by on-site due diligence.

## GitHub / Streamlit Cloud
Upload `app.py` and `requirements.txt` plus the `data` folder is not required for this version. Deploy `app.py` as the main file.
